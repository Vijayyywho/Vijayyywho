import app from "../src/img/App1.png";
import soft from "../src/img/soft.png";
import webs from "../src/img/web.png"


const Sdata =[
   { imgsrc: webs,
    title: "Web develepoment"
   },
   {
    imgsrc:app,
    title: "App development",
   },
   {
imgsrc: soft,
title:"Software development"
   }
];
export default Sdata;